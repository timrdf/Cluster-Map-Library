The Aduna Cluster Map Library is copyright Aduna (http://www.aduna-software.com/) � 1997-2006.
Licensed under the Open Software License version 3.0.
By using, modifying or distributing this software you agree to be bound by the terms of this license.